"""
Project: Hospital Patient Flow and Waiting-Time Analytics
File: data_cleaning.py

Purpose:
Load the synthetic raw hospital visit dataset, validate and clean it,
derive useful time fields, and export clean_dataset.csv.

Note: The input data is synthetic and intended for academic demonstration.
"""

from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
INPUT_FILE = BASE_DIR / "hospital_patient_flow_synthetic_dataset.csv"
OUTPUT_FILE = BASE_DIR / "clean_dataset.csv"


def clean_hospital_data(input_file=INPUT_FILE, output_file=OUTPUT_FILE):
    # 1. Load source data
    df = pd.read_csv(input_file)
    initial_rows = len(df)

    # 2. Remove duplicate records and normalize text fields
    df = df.drop_duplicates()
    text_columns = ["Patient_ID", "Gender", "Department", "Triage_Level",
                    "Outcome", "Day_of_Week"]
    for column in text_columns:
        if column in df.columns:
            df[column] = df[column].astype("string").str.strip()

    # 3. Convert date/time and numeric columns to appropriate data types
    date_columns = ["Visit_Date", "Arrival_Datetime",
                    "Doctor_Start_Datetime", "Completion_Datetime"]
    for column in date_columns:
        df[column] = pd.to_datetime(df[column], errors="coerce")

    numeric_columns = ["Age", "Waiting_Time_Minutes",
                       "Service_Time_Minutes", "Total_Time_Minutes",
                       "Arrival_Hour"]
    for column in numeric_columns:
        df[column] = pd.to_numeric(df[column], errors="coerce")

    # 4. Remove rows missing essential identifiers or timestamps
    df = df.dropna(subset=["Patient_ID", "Arrival_Datetime",
                           "Doctor_Start_Datetime", "Completion_Datetime"])

    # 5. Remove impossible values and invalid time sequences
    df = df[df["Age"].between(0, 120)]
    df = df[
        (df["Waiting_Time_Minutes"] >= 0) &
        (df["Service_Time_Minutes"] >= 0) &
        (df["Total_Time_Minutes"] >= 0)
    ]
    df = df[
        (df["Doctor_Start_Datetime"] >= df["Arrival_Datetime"]) &
        (df["Completion_Datetime"] >= df["Doctor_Start_Datetime"])
    ]

    # 6. Recalculate duration fields from timestamps for consistency
    df["Waiting_Time_Minutes"] = (
        (df["Doctor_Start_Datetime"] - df["Arrival_Datetime"])
        .dt.total_seconds() / 60
    ).round().astype("int64")

    df["Service_Time_Minutes"] = (
        (df["Completion_Datetime"] - df["Doctor_Start_Datetime"])
        .dt.total_seconds() / 60
    ).round().astype("int64")

    df["Total_Time_Minutes"] = (
        df["Waiting_Time_Minutes"] + df["Service_Time_Minutes"]
    )

    # 7. Derive fields useful for analysis and dashboard filters
    df["Visit_Date"] = df["Arrival_Datetime"].dt.date
    df["Arrival_Hour"] = df["Arrival_Datetime"].dt.hour
    df["Day_of_Week"] = df["Arrival_Datetime"].dt.day_name()
    df["Arrival_Period"] = pd.cut(
        df["Arrival_Hour"],
        bins=[-1, 5, 11, 16, 20, 23],
        labels=["Night", "Morning", "Afternoon", "Evening", "Late Evening"]
    )

    # 8. Sort and export
    df = df.sort_values("Arrival_Datetime").reset_index(drop=True)
    df.to_csv(output_file, index=False)

    print("HOSPITAL DATA CLEANING SUMMARY")
    print("--------------------------------")
    print(f"Rows before cleaning : {initial_rows}")
    print(f"Rows after cleaning  : {len(df)}")
    print(f"Rows removed         : {initial_rows - len(df)}")
    print(f"Average waiting time : {df['Waiting_Time_Minutes'].mean():.2f} minutes")
    print(f"Clean file saved to  : {output_file}")


if __name__ == "__main__":
    clean_hospital_data()
