
import csv
import html

def read_csv(filename):
    with open(filename, "r", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))

def bar_chart(title, labels, values, color):
    max_value = max(values) if values else 1
    bars = ""

    for label, value in zip(labels, values):
        width = (value / max_value) * 100
        bars += f"""
        <div class="bar-row">
          <span>{html.escape(str(label))}</span>
          <div class="track">
            <div class="fill" style="width:{width}%;background:{color}">
              {value}
            </div>
          </div>
        </div>
        """

    return f"<h2>{title}</h2>{bars}"


departments = read_csv("department_analysis.csv")
hours = read_csv("hourly_analysis.csv")
triage = read_csv("triage_analysis.csv")
outcomes = read_csv("outcome_analysis.csv")

department_chart = bar_chart(
    "Average Waiting Time by Department",
    [r["Department"] for r in departments],
    [float(r["Avg_Wait"]) for r in departments],
    "#2563eb"
)

hour_chart = bar_chart(
    "Patient Arrivals by Hour",
    [r["Arrival_Hour"] + ":00" for r in hours],
    [int(r["Patients"]) for r in hours],
    "#0891b2"
)

triage_chart = bar_chart(
    "Triage Distribution",
    [r["Triage_Level"] for r in triage],
    [int(r["Patients"]) for r in triage],
    "#7c3aed"
)

outcome_chart = bar_chart(
    "Patient Outcomes",
    [r["Outcome"] for r in outcomes],
    [int(r["Patients"]) for r in outcomes],
    "#059669"
)

summary = read_csv("department_analysis.csv")

page = f"""
<!DOCTYPE html>
<html>
<head>
<title>Hospital Analytics Dashboard</title>
<style>
body {{
    font-family: Arial, sans-serif;
    background: #f1f5f9;
    padding: 25px;
    color: #1e293b;
}}
h1 {{ text-align: center; color: #12345a; }}
.grid {{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(320px,1fr));
    gap: 20px;
}}
.card {{
    background: white;
    padding: 22px;
    border-radius: 12px;
    box-shadow: 0 2px 8px #00000015;
}}
.bar-row {{
    margin: 14px 0;
}}
.track {{
    background: #e2e8f0;
    height: 25px;
    border-radius: 5px;
    overflow: hidden;
}}
.fill {{
    height: 25px;
    color: white;
    padding-left: 6px;
    box-sizing: border-box;
    font-size: 13px;
}}
.note {{
    text-align: center;
    margin-top: 25px;
    color: #64748b;
}}
</style>
</head>
<body>

<h1>Hospital Patient Flow and Waiting-Time Analytics</h1>

<div class="grid">
<div class="card">{department_chart}</div>
<div class="card">{hour_chart}</div>
<div class="card">{triage_chart}</div>
<div class="card">{outcome_chart}</div>
</div>

<p class="note">
Academic project dashboard | Synthetic hospital dataset
</p>

</body>
</html>
"""

with open("Hospital_Dashboard.html", "w", encoding="utf-8") as f:
    f.write(page)

print("Visualisation completed successfully!")
print("Generated: Hospital_Dashboard.html")
