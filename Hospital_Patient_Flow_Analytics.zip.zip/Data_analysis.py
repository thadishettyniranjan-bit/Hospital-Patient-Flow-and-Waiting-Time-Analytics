
import csv
from collections import defaultdict, Counter
from statistics import mean

INPUT_FILE = "clean_dataset.csv"


def save_csv(filename, headers, rows):
    with open(filename, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(headers)
        writer.writerows(rows)


# Read dataset
with open(INPUT_FILE, "r", encoding="utf-8-sig") as file:
    reader = csv.DictReader(file)
    data = list(reader)

if not data:
    raise ValueError("The dataset is empty!")

# Convert numerical columns
for row in data:
    for column in [
        "Waiting_Time_Minutes",
        "Service_Time_Minutes",
        "Total_Time_Minutes",
        "Arrival_Hour"
    ]:
        row[column] = float(row[column])


# Overall statistics
total_patients = len(data)
avg_wait = mean(r["Waiting_Time_Minutes"] for r in data)
avg_service = mean(r["Service_Time_Minutes"] for r in data)
avg_total = mean(r["Total_Time_Minutes"] for r in data)


# Department analysis
departments = defaultdict(list)

for row in data:
    departments[row["Department"]].append(row)

department_rows = []

for department, records in departments.items():
    department_rows.append([
        department,
        len(records),
        round(mean(r["Waiting_Time_Minutes"] for r in records), 2),
        round(mean(r["Service_Time_Minutes"] for r in records), 2),
        round(mean(r["Total_Time_Minutes"] for r in records), 2)
    ])

save_csv(
    "department_analysis.csv",
    ["Department", "Patients", "Avg_Wait", "Avg_Service", "Avg_Total"],
    department_rows
)


# Hourly analysis
hours = defaultdict(list)

for row in data:
    hours[int(row["Arrival_Hour"])].append(row)

hourly_rows = []

for hour, records in sorted(hours.items()):
    hourly_rows.append([
        hour,
        len(records),
        round(mean(r["Waiting_Time_Minutes"] for r in records), 2)
    ])

save_csv(
    "hourly_analysis.csv",
    ["Arrival_Hour", "Patients", "Avg_Wait"],
    hourly_rows
)


# Daily analysis
days = defaultdict(list)

for row in data:
    days[row["Visit_Date"]].append(row)

daily_rows = []

for date, records in sorted(days.items()):
    daily_rows.append([
        date,
        len(records),
        round(mean(r["Waiting_Time_Minutes"] for r in records), 2)
    ])

save_csv(
    "daily_analysis.csv",
    ["Visit_Date", "Patients", "Avg_Wait"],
    daily_rows
)


# Triage analysis
triage_counts = Counter(r["Triage_Level"] for r in data)

save_csv(
    "triage_analysis.csv",
    ["Triage_Level", "Patients"],
    sorted(triage_counts.items())
)


# Outcome analysis
outcome_counts = Counter(r["Outcome"] for r in data)

save_csv(
    "outcome_analysis.csv",
    ["Outcome", "Patients"],
    sorted(outcome_counts.items())
)


# Find key results
busiest_department = max(departments, key=lambda d: len(departments[d]))

highest_wait_department = max(
    department_rows, key=lambda r: r[2]
)

peak_hour = max(hours, key=lambda h: len(hours[h]))


# Save summary
summary = f"""
HOSPITAL PATIENT FLOW AND WAITING-TIME ANALYTICS
------------------------------------------------

Total Patients: {total_patients}

Average Waiting Time: {avg_wait:.2f} minutes
Average Service Time: {avg_service:.2f} minutes
Average Total Time: {avg_total:.2f} minutes

Busiest Department: {busiest_department}
Department with Highest Average Waiting Time: {highest_wait_department[0]}
Peak Arrival Hour: {peak_hour}:00

TRIAGE DISTRIBUTION
{dict(triage_counts)}

PATIENT OUTCOMES
{dict(outcome_counts)}

Note: This project uses synthetic academic data,
not real hospital patient records.
"""

with open("analysis_summary.txt", "w", encoding="utf-8") as file:
    file.write(summary)

print(summary)
print("Analysis completed successfully!")
print("All analysis CSV files have been generated.")
